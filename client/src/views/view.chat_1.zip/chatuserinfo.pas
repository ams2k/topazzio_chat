unit ChatUserInfo;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Controls, Graphics, LCLType, LCLIntf;

type
  TChatUserStatus = (usOffline, usOnline);

  { TChatUserInfo }

  TChatUserInfo = class
  public
    Avatar: TBitmap;
    IsConvidado: Boolean;
    UserId: Integer;
    UserName: string;
    Status: TChatUserStatus;
    UnreadCount: Integer;

    constructor Create(AIsConvidado: Boolean; AUserId: Integer; AName: string; AStatus: TChatUserStatus);
    destructor Destroy; override;
  end;

implementation

{ TChatUserInfo }

constructor TChatUserInfo.Create(AIsConvidado: Boolean; AUserId: Integer; AName: string; AStatus: TChatUserStatus);
begin
  Avatar       := TBitmap.Create;
  IsConvidado  := AIsConvidado;
  UserId       := AUserId;
  UserName     := AName;
  Status       := AStatus;
  UnreadCount  := 0;
end;

destructor TChatUserInfo.Destroy;
begin
  Avatar.Free;
  inherited;
end;

end.

