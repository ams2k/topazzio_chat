unit View.Chat;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  Buttons, LCLType, LCLIntf, fpjson,
  FPImage, FPReadPNG, FPReadJPEG, FPReadGIF,
  ChatBubble, ChatBubbleFile, ChatLayoutManager, ChatUserInfo, Types;

type

  { TfrmChat }

  TfrmChat = class(TForm)
    btnUserStatus: TButton;
    btnEnviar: TSpeedButton;
    btnEuEnviar: TButton;
    btnFileOutroEnviar: TButton;
    btnOutroEnviar: TButton;
    btnFileEnviar: TButton;
    btnAddUser: TButton;
    edtMsgEU: TEdit;
    edtMsgFileOutro: TEdit;
    edtMsgOutro: TEdit;
    edtMsgFileEu: TEdit;
    imgIcons: TImageList;
    imgAvatar: TImage;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    lblTitulo1: TLabel;
    lblTitulo2: TLabel;
    ListBoxEmojis: TListBox;
    lstParticipantes: TListBox;
    edtMsg: TMemo;
    panTop: TPanel;
    scrChat: TScrollBox;
    procedure btnAddUserClick(Sender: TObject);
    procedure btnEnviarClick(Sender: TObject);
    procedure btnEuEnviarClick(Sender: TObject);
    procedure btnFileEnviarClick(Sender: TObject);
    procedure btnFileOutroEnviarClick(Sender: TObject);
    procedure btnOutroEnviarClick(Sender: TObject);
    procedure btnUserStatusClick(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure FormCreate(Sender: TObject);
    procedure FormResize(Sender: TObject);
    procedure ListBoxEmojisClick(Sender: TObject);
    procedure lstParticipantesClick(Sender: TObject);
    procedure lstParticipantesDrawItem(Control: TWinControl; Index: Integer;
      ARect: TRect; State: TOwnerDrawState);
    procedure lstParticipantesMeasureItem(Control: TWinControl; Index: Integer;
      var AHeight: Integer);
    procedure lstParticipantesMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure scrChatResize(Sender: TObject);
  private
    ChatLayout: TChatLayoutManager;
    Usuario_clicado: integer;
    procedure AdicionarBalaoInicial(ADate: TDateTime);
    procedure MsgRecebida(FromID: Integer; FromName: string; Msg: string);
    procedure ListaRecebida(Users: TJSONArray);
    procedure AdicionarBalao(ARemetente,ATexto: string; AEnviadaPorMim: Boolean);
    procedure AdicionarBalaoArquivo(AFileName: string; ASize: Int64;
      AEnviadaPorMim: Boolean);
    procedure BobbleClick(AChatID: Integer; AArquivo: string; ASize: Int64);
  public
    ChatRoom: string;
  end;

var
  frmChat: TfrmChat;

implementation

uses
  ChatModule, View.Main;

{$R *.lfm}

{ TfrmChat }

procedure TfrmChat.FormCreate(Sender: TObject);
begin
  ChatLayout := TChatLayoutManager.Create(scrChat);
  DMChatCliente.OnChat := @MsgRecebida;
  DMChatCliente.OnListUsers := @ListaRecebida;

  // Emojis compatíveis
  ListBoxEmojis.Items.AddStrings([
    '😀','😃','😄','😁','😆','😅','😂','🙂',
    '😉','😊','😍','😘','😜','😎',
    '😢','😭','😡','😱','😴','😇',
    '👍','👎','👌','🙌','👏',
    '❤️','💔','⭐','🔥','💡',
    '✔','❌','⚠','⚡','⏰',
    '📩','📤','📎','📞','🤩','😫'
  ]);

  lstParticipantes.Style := lbOwnerDrawVariable;
  lstParticipantes.ItemHeight := 60;
end;

procedure TfrmChat.FormResize(Sender: TObject);
begin
  ChatLayout.RecalculateLayout;
end;

procedure TfrmChat.ListBoxEmojisClick(Sender: TObject);
begin
  edtMsg.Text := edtMsg.Text + ListBoxEmojis.GetSelectedText;
end;

procedure TfrmChat.lstParticipantesClick(Sender: TObject);
var
  User: TChatUserInfo;
  status: string;
begin
  Usuario_clicado := 0;
  if lstParticipantes.ItemIndex < 0 then Exit;

  User := TChatUserInfo(lstParticipantes.Items.Objects[lstParticipantes.ItemIndex]);
  if (User.Status = usOnline) then
    status := 'Online'
  else
    status := 'Offline';

  Usuario_clicado := User.UserId;

  ShowMessage(
    'Usuário: ' + User.UserName + sLineBreak +
    'Status: ' + status
  );
end;

procedure TfrmChat.lstParticipantesDrawItem(Control: TWinControl; Index: Integer; ARect: TRect; State: TOwnerDrawState);
var
  User: TChatUserInfo;
  LB: TListBox;
  BtnRect, BadgeRect: TRect;
  StatusColor, BackColor: TColor;
  status: string;
  lImageIndex: integer;
begin
  LB := TListBox(Control);
  User := TChatUserInfo(LB.Items.Objects[Index]);
  lImageIndex := 0; //lixeira

  // Fundo
  if not User.IsConvidado then
    BackColor := $00E6FCD5 // $00DCF8C6; // verde WhatsApp
  else
    BackColor := $00F3F4E0; // $00EBECD8; //azul claro

  LB.Canvas.Brush.Color := BackColor;

  //cor quando este item estiver selecionado
  if odSelected in State then
    LB.Canvas.Brush.Color := $00F0E8E0;

  //LB.Canvas.FillRect(ARect);
  LB.Canvas.RoundRect(ARect, 12, 12);

  // Avatar (circular fake)
  if Assigned(User.Avatar) then
    LB.Canvas.StretchDraw(
      Rect(ARect.Left + 8, ARect.Top + 8, ARect.Left + 48, ARect.Top + 48),
      User.Avatar
    );

  // Nome
  LB.Canvas.Font.Style := [fsBold];
  LB.Canvas.Font.Size := 10;
  LB.Canvas.TextOut(ARect.Left + 56, ARect.Top + 10, User.UserName);

  // Status
  LB.Canvas.Font.Style := [];
  LB.Canvas.Font.Size := 9;

  if User.Status = usOnline then begin
    StatusColor := clGreen;
    status := 'online';
  end
  else begin
    StatusColor := clRed;
    status := 'offline';
  end;

  //desenho circular representando o status
  LB.Canvas.Brush.Color := StatusColor;
  LB.Canvas.Ellipse(
    ARect.Left + 56,
    ARect.Top + 30,
    ARect.Left + 76,
    ARect.Top + 58
  );

  // texto do status
  LB.Canvas.Font.Style := [];
  LB.Canvas.Font.Color := StatusColor;
  LB.Canvas.TextOut(
    ARect.Left + 82,
    ARect.Top + 28,
    status
  );

  // Badge mensagens não lidas
  if User.UnreadCount > 0 then begin
    BadgeRect := Rect(
      ARect.Right - 60,
      ARect.Top + 28,
      ARect.Right - 36,
      ARect.Top + 44
    );

    LB.Canvas.Brush.Color := clRed;
    LB.Canvas.Pen.Style := psClear;
    LB.Canvas.RoundRect(BadgeRect, 8, 8);

    LB.Canvas.Font.Color := clWhite;
    LB.Canvas.TextOut(
      BadgeRect.Left + 6,
      BadgeRect.Top + 2,
      IntToStr(User.UnreadCount)
    );
  end;

  // Botão lixeira
  if User.IsConvidado then begin
    //apenas para o criador do chat
    BtnRect := Rect(
      ARect.Right - 30,
      ARect.Top + 10,
      ARect.Right - 10,
      ARect.Top + 30
    );

    if Assigned(imgIcons) then
      imgIcons.Draw(LB.Canvas, BtnRect.Left + 2, BtnRect.Top + 2, lImageIndex, Enabled)
    else begin
      LB.Canvas.Font.Color := clGray;
      LB.Canvas.TextOut(BtnRect.Left + 2, BtnRect.Top, '🗑');;
    end;
  end;
end;

procedure TfrmChat.lstParticipantesMeasureItem(Control: TWinControl;  Index: Integer; var AHeight: Integer);
begin
  AHeight := 60;
end;

procedure TfrmChat.lstParticipantesMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
//remover participante ?
var
  Idx: Integer;
  ItemRect, BtnRect: TRect;
  User: TChatUserInfo;
begin
  Idx := lstParticipantes.ItemAtPos(Point(X, Y), True);
  if Idx < 0 then Exit;

  ItemRect := lstParticipantes.ItemRect(Idx);

  BtnRect := Rect(
    ItemRect.Right - 30,
    ItemRect.Top + 10,
    ItemRect.Right - 10,
    ItemRect.Top + 30
  );

  if PtInRect(BtnRect, Point(X, Y)) then begin
    User := TChatUserInfo(lstParticipantes.Items.Objects[idx]);
    if (User <> nil) then begin
      if MessageDlg('Remover Participante', 'Deseja remover este usuário?' + sLineBreak + User.UserName, mtConfirmation, [mbYes, mbNo], 0) = mrYes then begin
        TObject(lstParticipantes.Items.Objects[Idx]).Free;
        lstParticipantes.Items.Delete(Idx);
      end;
    end;
  end;
end;

procedure TfrmChat.scrChatResize(Sender: TObject);
// ajusta os elementos dentro do scroolview para ajustá-los
// quando a barra de rolagem surgir
begin
  ChatLayout.RecalculateLayout;
end;

procedure TfrmChat.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
var
 i: Integer;
begin
  FreeAndNil(ChatLayout);

  for i := 0 to lstParticipantes.Items.Count - 1 do
    TObject(lstParticipantes.Items.Objects[i]).Free;
end;

procedure TfrmChat.btnEnviarClick(Sender: TObject);
begin
  if Trim(edtMsg.Text) = '' then Exit;
  //if lstParticipantes.ItemIndex = -1 then Exit;

  //DMChatCliente.EnviarMensagem(StrToInt(lstParticipantes.Items[lstParticipantes.ItemIndex]), edtMsg.Text);
  // Adicionar balão localmente
  AdicionarBalao('Rodrigo Cesar Soares', edtMsg.Text, True);
  edtMsg.Clear;
  edtMsg.SetFocus;
end;

procedure TfrmChat.btnAddUserClick(Sender: TObject);
var
  U: TChatUserInfo;
  iduser: Integer;
  nome: string;
  isconvidado: Boolean;
begin
  isconvidado := lstParticipantes.Count > 0;
  iduser  := lstParticipantes.Count + 1;

  if not isconvidado then
    nome := 'Márcio'
  else begin
    nome := 'Pessoa ' + IntToStr(iduser);
    isconvidado := True;
  end;

  U := TChatUserInfo.Create(isconvidado, iduser, Nome, usOnline);
  //U.Avatar.LoadFromFile( ExtractFileDir(ParamStr(0)) + PathDelim + 'avatar.png');//erro
  u.Avatar.Assign(imgAvatar.Picture.Bitmap);

  lstParticipantes.Items.AddObject(U.UserName, U);
end;

procedure TfrmChat.btnEuEnviarClick(Sender: TObject);
begin
  AdicionarBalao('Aldo Márcio Soares', edtMsgEU.Text, True);
  edtMsgEU.Text := '';
end;

procedure TfrmChat.btnFileEnviarClick(Sender: TObject);
begin
  AdicionarBalaoArquivo(edtMsgFileEu.Text, 4 * 1024, true);
  edtMsgFileEu.Text := '';
end;

procedure TfrmChat.btnFileOutroEnviarClick(Sender: TObject);
begin
  AdicionarBalaoArquivo(edtMsgFileOutro.Text, 4 * 1024, false);
  edtMsgFileOutro.Text := '';
end;

procedure TfrmChat.btnOutroEnviarClick(Sender: TObject);
begin
  AdicionarBalao('Danilo Carlos Soares', edtMsgOutro.Text, False);
  edtMsgOutro.Text := '';
end;

procedure TfrmChat.btnUserStatusClick(Sender: TObject);
var
  i: Integer;
  U: TChatUserInfo;
begin
  for i := 0 to lstParticipantes.Items.Count - 1 do begin
    U := TChatUserInfo(lstParticipantes.Items.Objects[i]);
    if U.UserId = Usuario_clicado then begin
      if U.Status = usOffline then
        U.Status := usOnline
      else
        U.Status := usOffline;

      U.UnreadCount := U.UnreadCount + 1;

      lstParticipantes.Invalidate;
      Break;
    end;
  end;
end;

procedure TfrmChat.MsgRecebida(FromID: Integer; FromName: string; Msg: string);
begin
  // Se estiver na conversa com FromID, adiciona o balão
  AdicionarBalao(FromName, Msg, False);
end;

procedure TfrmChat.ListaRecebida(Users: TJSONArray);
var
  i: Integer;
begin
  lstParticipantes.Items.BeginUpdate;
  lstParticipantes.Items.Clear;

  for i := 0 to Users.Count -1 do
    if Users.Objects[i].Integers['id'] <> DMChatCliente.Meu_ID then
      lstParticipantes.Items.Add( Users.Objects[i].Strings['id'] );

  lstParticipantes.Items.EndUpdate;
end;

procedure TfrmChat.AdicionarBalao(ARemetente, ATexto: string;
  AEnviadaPorMim: Boolean);
var
  Balao: TChatBubble;
  TimeStr: string;
begin
  if scrChat.ControlCount = 0 then
    AdicionarBalaoInicial(Now);

  TimeStr := FormatDateTime('hh:nn', Now);

  Balao := TChatBubble.Create(scrChat);
  Balao.Parent := scrChat;
  Balao.Constraints.MaxWidth := Trunc(scrChat.ClientWidth * 0.75);
  Balao.Setup(1, ARemetente, ATexto, TimeStr, AEnviadaPorMim, TBubbleMessageStatus.msRead);

  ChatLayout.AddBubble(Balao);
end;

procedure TfrmChat.AdicionarBalaoArquivo(AFileName: string; ASize: Int64; AEnviadaPorMim: Boolean);
var
  Balao: TChatBubbleFile;
  TimeStr: string;
begin
  if scrChat.ControlCount = 0 then
    AdicionarBalaoInicial(Now);

  TimeStr := FormatDateTime('hh:nn', Now);

  Balao := TChatBubbleFile.Create(scrChat);
  Balao.Parent := scrChat;
  Balao.Constraints.MaxWidth := Trunc(scrChat.ClientWidth * 0.75);
  Balao.ImageList := frmMain.imgChatIcones;
  Balao.OnClickEvent := @BobbleClick;
  Balao.Setup(1, AFileName, ASize, TimeStr, AEnviadaPorMim, TBubbleFileMessageStatus.msRead);

  ChatLayout.AddBubbleFile(Balao);
end;

procedure TfrmChat.BobbleClick(AChatID: Integer; AArquivo: string; ASize: Int64);
begin
  ShowMessage(AArquivo);
end;

procedure TfrmChat.AdicionarBalaoInicial(ADate: TDateTime);
//exibe a data inicial do chat
var
  Balao: TChatBubble;
begin
  Balao := TChatBubble.Create(scrChat);
  Balao.Parent := scrChat;
  Balao.Constraints.MaxWidth := Trunc(scrChat.ClientWidth * 0.75);
  Balao.InitialDate(ADate);

  ChatLayout.AddBubble(Balao);
end;

end.

