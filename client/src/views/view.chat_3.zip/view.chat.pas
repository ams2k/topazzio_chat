unit View.Chat;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  Buttons, LCLType, LCLIntf, ComCtrls, IniFiles, lNetComponents, lNet, lFTP, fpjson,
  ChatCardMessage, ChatCardFile, ChatLayoutManager, ChatUserInfo;

type
  TTransferFiles = (tfUpload, tfDownload, tfNone);

  { TfrmChat }

  TfrmChat = class(TForm)
    btnChamarAtencao: TSpeedButton;
    FTP: TLFTPClientComponent;
    btnEnviarArquivo: TSpeedButton;
    imgChatIcones: TImageList;
    lblStatus: TLabel;
    lblPanArquivoClose: TLabel;
    lblLogOpen: TLabel;
    lblLogTitulo: TLabel;
    lblPanArquivoNome: TLabel;
    lblPanArq1: TLabel;
    lblPanArq2: TLabel;
    lblPanArquivoSize: TLabel;
    lblPanArquivoCount: TLabel;
    lblTituloConvidados: TLabel;
    lblTituloChat: TLabel;
    lblTituloEmoji: TLabel;
    edtLogs: TMemo;
    OpenDialog1: TOpenDialog;
    panArquivo: TPanel;
    panWriting: TPanel;
    panLog: TPanel;
    panTitulo: TPanel;
    lblPanTitulo1: TLabel;
    lblPanTitulo2: TLabel;
    ProgressBar1: TProgressBar;
    SaveDialog1: TSaveDialog;
    scrChat: TScrollBox;
    scrConvidados: TScrollBox;
    ListBoxEmojis: TListBox;
    btnEnviarMsg: TSpeedButton;
    imgIcons20: TImageList;
    edtMsg: TMemo;
    btnAdidcionaConvidados: TSpeedButton;
    Timer1: TTimer;

    procedure btnChamarAtencaoClick(Sender: TObject);
    procedure edtMsgKeyUp(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormDropFiles(Sender: TObject; const AFileNames: array of string);
    procedure FormResize(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure FTPConnect(aSocket: TLSocket);
    procedure FTPControl(aSocket: TLSocket);
    procedure FTPError(const msg: string; aSocket: TLSocket);
    procedure FTPFailure(aSocket: TLSocket; const aStatus: TLFTPStatus);
    procedure FTPReceive(aSocket: TLSocket);
    procedure FTPSent(aSocket: TLSocket; const Bytes: Integer);
    procedure FTPSuccess(aSocket: TLSocket; const aStatus: TLFTPStatus);
    procedure lblLogOpenClick(Sender: TObject);
    procedure lblLogOpenMouseEnter(Sender: TObject);
    procedure lblLogOpenMouseLeave(Sender: TObject);
    procedure lblPanArquivoCloseClick(Sender: TObject);
    procedure scrChatResize(Sender: TObject);
    procedure scrConvidadosResize(Sender: TObject);
    procedure btnAdidcionaConvidadosClick(Sender: TObject);
    procedure btnEnviarArquivoClick(Sender: TObject);
    procedure btnEnviarMsgClick(Sender: TObject);
    procedure ListBoxEmojisClick(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
  private
    FFile: TFileStream;
    ChatLayout: TChatLayoutManager;
    ConvidadosLayout: TChatLayoutManager;
    Usuario_clicado: integer;
    FTotalBytes, FTransferred: Int64;
    FTotalArquivos, FTotalArquivosTransferidos: Integer;
    ListaIDS: string;
    FConnected: Boolean;
    FAuthenticated: Boolean;
    FWaitingSize: Boolean;
    FTransferConcluded: Boolean;
    FServer_Host: string;
    FServer_Port: Integer;
    FServer_User: string;
    FServer_Pwd: string;
    FServer_Folder: string;
    FFtpErroMsg: string;
    FFilesToSend: array of string;
    FFileCurrentIndex: Integer;
    FFileCurrentSize: Int64;
    FCreateFilePath, FCurrentFileName: string;
    FMaxFileSize: Int64;
    FDirListing: string;
    bAnimarLog: Boolean;
    AnimarDirecao: Integer;
    AnimarVelocidade: Integer;
    FConvidados_List: TJSONArray;
    FAttention: Boolean;
    FAttentionPeriod, FAttentionCount, FAttentionSequence: Integer;
    FWriting: Boolean;
    FWritingPeriod, FWritingCount, FWritingSequence: Integer;
    FDefaultColor: TColor;
    FDigitandoCount: Integer;

    procedure AdicionarCardMessageInicial(ADate: TDateTime);
    procedure AdicionarConvidado(AIdOwner, AIdUser: Integer);
    procedure ChamarAtencao;
    procedure ConvidadoAlteraStatus(AIdUser: Integer; AStatus: Boolean);
    procedure ConvidadoMsgNaoLidas(AIdUser, AQdeNaoLida: Integer);
    procedure EnviarArquivos(const AFileNames: array of string);
    procedure EnviarMensagem(AEvent, AMessage, AFileName, AFileSize: string);
    function GetFileSizeText(AValue: Int64): string;
    function GetLocalFileSize(const AFileName: string): Int64;
    function GetToUsers: TJSONArray;
    procedure AdicionarCardMessage(ARemetente,ATexto: string; AEnviadaPorMim: Boolean);
    procedure AdicionarCardFile(AFileName: string; ASize: Int64; AEnviadaPorMim: Boolean);
    procedure CardFileClick(AChatID: Integer; AArquivo: string; ASize: Int64);
    procedure ConvidadoClickDelete(AIDUser: Integer; ANomeUser: string);
    procedure ConvidadoClickInfo(AIDUser: Integer; ANomeUser: string);
    procedure NotificaDigitacao;
    function PodeEnviarMensagem(): Boolean;
    function GetFileTotalBytes(AData: string): Int64;
    procedure ControleElementos(AEnabled: Boolean);
    procedure LerConfig;
    procedure ConectarFTP;
    procedure DesconectarFTP;
    procedure SendFile;
    function IsMinhaSala(): Boolean;
    function IdDonoSala(): integer;
    procedure ResetAttention;
    procedure ResetWriting;
  public
    ChatRoom: string;
    { apenas o evento 'chat' }
    procedure ChatEventos(ASala: string; AJson: TJSONObject);
    { avisos como: logoff de usuáro, entre outras mensagens }
    procedure ChatAvisos(AJson: TJSONObject);
  end;

var
  frmChat: TfrmChat;

implementation

uses
  ChatModule,
  View.Main, View.MessageQuery, View.ChatUsuarios,
  Util.MessagePopup;

const
  FLE = #13#10;

{$R *.lfm}

{ TfrmChat }

procedure TfrmChat.FormCreate(Sender: TObject);
begin
  Self.AllowDropFiles := True;
  panLog.Left := Self.Width - 14;
  lblStatus.Caption := '';
  ChatRoom := ChatClient.NewRoom( frmMain.GetUsuario_ID );
  ChatLayout := TChatLayoutManager.Create( scrChat );
  ConvidadosLayout := TChatLayoutManager.Create( scrConvidados );
  ListaIDS := frmMain.GetUsuario_ID.ToString;
  FTotalBytes := 0;
  FTransferred := 0;
  FTotalArquivos := 0;
  FTotalArquivosTransferidos := 0;
  FConnected := False;
  FAuthenticated := False;
  FFtpErroMsg := '';
  FTransferConcluded := False;
  FFileCurrentIndex := -1;
  FCreateFilePath := '';
  FCurrentFileName := '';
  FDirListing := '';
  FMaxFileSize := 1024 * 1024 * 4; //4Mb
  FDefaultColor := panTitulo.Color;
  ResetAttention;
  ResetWriting;
  FDigitandoCount := 0;

  LerConfig;

  // Emojis compatíveis
  ListBoxEmojis.Items.AddStrings([
    '😀','😃','😄','😁','😆','😅',
    '😂','🙂','😉','😊','😍','😘',
    '😜','😎','😢','😭','😡','😱',
    '😴','😇','🤩','😫','❤️','💔',
    '👍','👎','👌','🙌','👏','⭐',
    '🔥','💡','✔' ,'❌','⚠' ,'⚡',
    '⏰','🍀','📩','📤','📎','📞'
  ]);


  ConectarFTP;
end;

procedure TfrmChat.FormDestroy(Sender: TObject);
begin
  ChatClient.CloseChat(ChatRoom);
end;

procedure TfrmChat.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
  FreeAndNil(ChatLayout);
  FreeAndNil(ConvidadosLayout);
  FreeAndNil(FFile);

  edtLogs.Lines.SaveToFile('chatlog.txt');

  if Assigned(FFilesToSend) then
    SetLength(FFilesToSend, 0);
end;

procedure TfrmChat.edtMsgKeyUp(Sender: TObject; var Key: Word; Shift: TShiftState);
//se estou escrevendo, notifico a todos da sala
begin
  FDigitandoCount := FDigitandoCount + 1;
  if FDigitandoCount > 5 then begin
    FDigitandoCount := 0;
    NotificaDigitacao;
  end;
end;

procedure TfrmChat.btnChamarAtencaoClick(Sender: TObject);
//pedir atenção aos participamentes da sala
begin
  if not PodeEnviarMensagem() then Exit;
  if ShowMessageQuery(self, 'Pedir atenção','Pedir atenção aos participantes da sala ?','Sim','Não','',icQuestion) <> mrYes then Exit;
  ChamarAtencao;
end;

procedure TfrmChat.FormDropFiles(Sender: TObject; const AFileNames: array of string);
//arrastando e soltando os arquivos
var
  P: TPoint;
begin

  //posição do mouse no momento em que os arquivos foram soltos
  P := ScreenToClient(Mouse.CursorPos);

  //Verifica se o controle é a ScrollBox do chat
  if (PtInRect(scrChat.BoundsRect, P)) then
    EnviarArquivos(AFileNames);
end;

procedure TfrmChat.FormResize(Sender: TObject);
begin
  panLog.Left := Self.Width - 14;
  panLog.Width := Self.Width - 4;
end;

procedure TfrmChat.FormShow(Sender: TObject);
begin
  btnAdidcionaConvidados.Visible := IsMinhaSala();
end;

procedure TfrmChat.FTPConnect(aSocket: TLSocket);
//conectou no host
var
  msg: string;
begin
  FConnected := True;
  msg := '';

  if FTP.Authenticate(FServer_User, FServer_Pwd) then begin //autentica o usuário
    FTP.Binary := True;
    FAuthenticated := True;

    if (FServer_Folder <> '') and (FServer_Folder <> '/') then
      FTP.ChangeDirectory(FServer_Folder);

    FTP.ListFeatures;
  end else begin
    FTP.GetMessage(msg);
    if Length(msg) = 0 then msg := 'Falha na autenticação do usuário';
  end;
end;

procedure TfrmChat.FTPControl(aSocket: TLSocket);
//retorno do FTP.SendMessage(... + #13#10)
var
  s: string;
begin
  if FTP.GetMessage(s) > 0 then begin
    edtLogs.Lines.Append(s);

    if FWaitingSize and (Pos('213', s) = 1) then begin
      // FTP.SendMessage('SIZE arquivo.ext' + FLE)
      // resposta padrão do FTP para SIZE
      // 213 153245
      // 550 Could not get file size
      FTotalBytes := StrToInt64Def(Trim(Copy(s, 4, Length(s))), 0);
      FWaitingSize := False;
    end;

  end;
end;

procedure TfrmChat.FTPError(const msg: string; aSocket: TLSocket);
begin
  FCreateFilePath := '';
  panArquivo.Visible := False;
  edtLogs.Lines.Append(msg);
  DesconectarFTP;
end;

procedure TfrmChat.FTPFailure(aSocket: TLSocket; const aStatus: TLFTPStatus);
begin
  panArquivo.Visible := False;
  edtLogs.Lines.Append('Failure');

  case aStatus of
    fsNone: edtLogs.Lines.Append('fsNone');
    fsCon:  edtLogs.Lines.Append('fsCon');
    fsUser: edtLogs.Lines.Append('fsUser');
    fsPass: edtLogs.Lines.Append('fsPass');
    fsPasv: edtLogs.Lines.Append('fsPasv');
    fsPort: edtLogs.Lines.Append('fsPort');
    fsList: edtLogs.Lines.Append('fsList');
    fsRetr: edtLogs.Lines.Append('fsRetr');
    fsStor: edtLogs.Lines.Append('fsStor');
    fsType: edtLogs.Lines.Append('fsType');
    fsCWD:  edtLogs.Lines.Append('fsCWD');
    fsMKD:  edtLogs.Lines.Append('fsMKD');
    fsRMD:  edtLogs.Lines.Append('fsRMD');
    fsDEL:  edtLogs.Lines.Append('fsDEL');
    fsRNFR: edtLogs.Lines.Append('fsRNFR');
    fsRNTO: edtLogs.Lines.Append('fsRNTO');
    fsSYS:  edtLogs.Lines.Append('fsSYS');
    fsFeat: edtLogs.Lines.Append('fsFeat');
    fsPWD:  edtLogs.Lines.Append('fsPWD');
    fsHelp: edtLogs.Lines.Append('fsHelp');
    fsQuit: edtLogs.Lines.Append('fsQuit');
    fsLast: edtLogs.Lines.Append('fsLast');
  end;
end;

procedure TfrmChat.FTPReceive(aSocket: TLSocket);
//download
var
  Buf: array[0..65535] of Byte;
  N: Integer;
  s: string;
begin
  if FTP.CurrentStatus = fsRetr then begin
    N := FTP.GetData(Buf, SizeOf(Buf));
    Inc(FTransferred, N);
    ProgressBar1.Position := Round(FTransferred / FTotalBytes * 100);

    if N > 0 then begin
      //download em andamento
      if Length(FCreateFilePath) > 0 then begin
        FFile := TFileStream.Create(FCreateFilePath, fmCreate or fmOpenWrite);
        FCreateFilePath := '';
      end;

      FFile.Write(Buf, N);
    end else if (N < 1) or not FTP.DataConnection.Connected then begin
      //download concluído
      FreeAndNil(FFile);  // fecha o arquivo
      FTransferConcluded := True;
      FCreateFilePath := '';
      ProgressBar1.Position := 100;
      Sleep(2000);
      panArquivo.Visible := False;
    end;
  end else begin
    //listagem aqui:
    //FTP.List('gotify.png') => '-rw-r--r--    1 1003     1004        15750 Jan 18 17:16 gotify.png'
    //FTP.FeatureList;
    s := FTP.GetDataMessage;

    if Length(s) > 0 then
      //lendo a informação
      FDirListing := FDirListing + s
    else begin
      //leitura concluída
      edtLogs.Lines.Append( FDirListing );

      if FWaitingSize then begin
         FTotalBytes := GetFileTotalBytes( FDirListing );
         FWaitingSize := False;
      end;

      FDirListing := '';
    end;
  end;
end;

procedure TfrmChat.FTPSent(aSocket: TLSocket; const Bytes: Integer);
begin
  if Bytes > 0 then begin
    Inc(FTransferred, Bytes);
    ProgressBar1.Position := Round(FTransferred / FTotalBytes * 100);
  end else begin
    if FTP.DataConnection.Connected then begin
      SendFile; //próximo arquivo da lista
      FTransferConcluded := True;
    end;
    if (FTransferred >= FTotalBytes) then begin
      FTransferConcluded := True;
      panArquivo.Visible := True;
      ProgressBar1.Position := 100;
      Sleep(2000);
      panArquivo.Visible := False;
    end;
  end;
end;

procedure TfrmChat.FTPSuccess(aSocket: TLSocket; const aStatus: TLFTPStatus);
begin
  //
end;

procedure TfrmChat.lblLogOpenClick(Sender: TObject);
begin
  bAnimarLog := True;
  AnimarVelocidade := 120;

  if AnimarDirecao = -1 then begin
    AnimarDirecao := 1;
    lblLogOpen.Hint := 'Exibir';
  end
  else begin
    AnimarDirecao := -1;
    lblLogOpen.Hint := 'Ocultar';
  end;
end;

procedure TfrmChat.lblLogOpenMouseEnter(Sender: TObject);
begin
  lblLogOpen.Color := clSkyBlue;
end;

procedure TfrmChat.lblLogOpenMouseLeave(Sender: TObject);
begin
  lblLogOpen.Color := clGray;
end;

procedure TfrmChat.lblPanArquivoCloseClick(Sender: TObject);
begin
  panArquivo.Visible := False;
end;

procedure TfrmChat.ListBoxEmojisClick(Sender: TObject);
begin
  edtMsg.Text := edtMsg.Text + ListBoxEmojis.GetSelectedText;
end;

procedure TfrmChat.Timer1Timer(Sender: TObject);
begin
  //exibe ou esconde a tela de log
  if bAnimarLog then begin
    if AnimarDirecao = -1 then begin
      //exibir Logs
      if (panLog.Left < 200) then AnimarVelocidade := 10;
      if panLog.Left > 4 then
        panLog.Left := panLog.Left - AnimarVelocidade;
      if panLog.Left <= 4 then begin
        panLog.left := 4;
        bAnimarLog := False;
      end;
    end else if AnimarDirecao = 1 then begin
      //ocultar Logs
      if (panLog.Left > Self.Width - 200) then AnimarVelocidade := 10;
      if panLog.Left < (Self.Width - 14) then
        panLog.Left := panLog.Left + AnimarVelocidade;
      if panLog.Left >= (Self.Width - 14) then begin
        panLog.Left := Self.Width - 14;
        bAnimarLog := False;
      end;
    end;
  end;

  //alguém chamando a atenção
  if FAttention then begin
    if FAttentionPeriod = 1 then begin
      panTitulo.Color := clRed;
      FAttentionCount := FAttentionCount + 1;
      if FAttentionCount > 15 then begin
        panTitulo.Color := FDefaultColor;
        FAttentionCount := 0;
        FAttentionPeriod := 2;
        FAttentionSequence := FAttentionSequence + 1;
      end;
    end else if FAttentionPeriod = 2 then begin
      FAttentionCount := FAttentionCount + 1;
      if FAttentionCount > 10 then begin
        FAttentionCount := 0;
        FAttentionPeriod := 1;
        FAttentionSequence := FAttentionSequence + 1;
      end;
    end;
    if FAttentionSequence > 8 then begin
      FAttention := False;
      ResetAttention;
    end;
  end; //if FAttention

  //convidado escrevendo
  if FWriting then begin
    if FWritingSequence = 0 then begin
      panWriting.Left := scrChat.Left + 3;
      panWriting.Top := scrChat.Top + scrChat.Height - panWriting.Height - 4;
      panWriting.Visible := True;
      panWriting.BringToFront;
      panWriting.Refresh;
    end;
    if FWritingPeriod = 1 then begin
      FWritingCount := FWritingCount + 1;
      if FWritingCount > 15 then begin
        panWriting.Visible := False;
        FWritingCount := 0;
        FWritingPeriod := 2;
        FWritingSequence := FWritingSequence + 1;
      end;
    end else if FWritingPeriod = 2 then begin
      FWritingCount := FWritingCount + 1;
      if FWritingCount > 10 then begin
        panWriting.Visible := True;
        FWritingCount := 0;
        FWritingPeriod := 1;
        FWritingSequence := FWritingSequence + 1;
      end;
    end;
    if FWritingSequence > 8 then begin
      FWriting := False;
      ResetWriting;
    end;
  end; //if FWritting
end;

procedure TfrmChat.scrChatResize(Sender: TObject);
// ajusta os elementos dentro do scrollview para ajustá-los
// quando a barra de rolagem surgir
begin
  ChatLayout.RecalculateLayout;
end;

procedure TfrmChat.scrConvidadosResize(Sender: TObject);
// ajusta os elementos dentro do scrollview para ajustá-los
// quando a barra de rolagem surgir
begin
  ConvidadosLayout.RecalculateLayout;
end;

procedure TfrmChat.btnEnviarMsgClick(Sender: TObject);
begin
  if Trim(edtMsg.Text) = '' then Exit;
  if not PodeEnviarMensagem() then Exit;

  EnviarMensagem('chat', edtMsg.Text, '', '');

  FDigitandoCount := 0;
  edtMsg.Clear;
  edtMsg.SetFocus;
end;

procedure TfrmChat.btnAdidcionaConvidadosClick(Sender: TObject);
//adicionar convidados ao chat
var
  f: TfrmChatUsuarios;
  i, iduser: Integer;
begin
  //abrir a tela para selecionar convidados
  f := TfrmChatUsuarios.Create(Self);
  f.ListaExcluidos := ListaIDS;
  f.ShowModal;

  if f.Selecionou then begin

    if scrConvidados.ControlCount = 0 then begin
      //adiciona o dono do chat, eu mesmo
      AdicionarConvidado(frmMain.GetUsuario_ID, frmMain.GetUsuario_ID);
    end;

    for i := 0 to f.ListaConvidados.Count -1 do begin
      iduser := StrToIntDef( f.ListaConvidados[i], 0);

      if (iduser = 0) then
        iduser := StrToIntDef( f.ListaConvidados[i].Split(['_'], TStringSplitOptions.ExcludeEmpty)[1], 0 );

      if (iduser > 0) and (iduser <> frmMain.GetUsuario_ID) then
        AdicionarConvidado(frmMain.GetUsuario_ID, iduser);
    end; //for

  end; //if

  f.Free;

  //lista de convidados
  FConvidados_List := GetToUsers;
end;

procedure TfrmChat.btnEnviarArquivoClick(Sender: TObject);
var
  lArquivos: array of String;
  i: integer;
  bOK: Boolean;
begin
  if not PodeEnviarMensagem() then Exit;
  if not FTP.Connected or not FAuthenticated then begin
    ConectarFTP;
    Sleep(100);
  end;

  bOK := False;
  with OpenDialog1 do begin
    if Execute then
      if (Files.Count > 0) then begin
        SetLength(lArquivos, Files.Count);
        bOK := True;
        for i := 0 to Files.Count - 1 do
          lArquivos[i] := Files[i];
      end;
  end;

  if bOK then
    EnviarArquivos(lArquivos);

  SetLength(lArquivos, 0);
end;

procedure TfrmChat.ConvidadoAlteraStatus(AIdUser: Integer; AStatus: Boolean);
//altera o status (on/off line) do convidado
var
  i: Integer;
  U: TChatUserInfo;
begin
  if AIdUser < 1 then Exit;

  for i := 0 to scrConvidados.ComponentCount - 1 do begin
    U := TChatUserInfo(scrConvidados.Components[i]);
    if U.Usuario_ID = AIdUser then begin
      if AStatus then
        U.Status := usOnline
      else
        U.Status := usOffline;
      Break;
    end;
  end;
end;

procedure TfrmChat.ConvidadoMsgNaoLidas(AIdUser, AQdeNaoLida: Integer);
//altera msg não lida do convidado
var
  i: Integer;
  U: TChatUserInfo;
begin
  if AIdUser < 1 then Exit;

  for i := 0 to scrConvidados.ComponentCount - 1 do begin
    U := TChatUserInfo(scrConvidados.Components[i]);
    if U.Usuario_ID = AIdUser then begin
      U.UnreadCount := AQdeNaoLida;
      //scrConvidados.Invalidate;
      Break;
    end;
  end;
end;

procedure TfrmChat.AdicionarCardMessage(ARemetente, ATexto: string;
  AEnviadaPorMim: Boolean);
var
  CardMsg: TChatCardMessage;
  TimeStr: string;
begin
  if scrChat.ControlCount = 0 then
    AdicionarCardMessageInicial(Now);

  TimeStr := FormatDateTime('hh:nn', Now);

  CardMsg := TChatCardMessage.Create(scrChat);
  CardMsg.Parent := scrChat;
  CardMsg.Setup(1, ARemetente, ATexto, TimeStr, AEnviadaPorMim, TChatCardMessageStatus.msRead);

  ChatLayout.AddCardMessage(CardMsg);
end;

procedure TfrmChat.AdicionarCardFile(AFileName: string; ASize: Int64; AEnviadaPorMim: Boolean);
//envia mensagem de remessa de arquivo
var
  CardFile: TChatCardFile;
  TimeStr: string;
begin
  if scrChat.ControlCount = 0 then
    AdicionarCardMessageInicial(Now);

  TimeStr := FormatDateTime('hh:nn', Now);

  CardFile := TChatCardFile.Create(scrChat);
  CardFile.Parent := scrChat;
  CardFile.ImageList := imgChatIcones;
  CardFile.OnClickEvent := @CardFileClick;
  CardFile.Setup(1, AFileName, ASize, TimeStr, AEnviadaPorMim, TChatCardFileStatus.msRead);

  ChatLayout.AddCardFile(CardFile);
end;

procedure TfrmChat.CardFileClick(AChatID: Integer; AArquivo: string; ASize: Int64);
//baixar arquivo clicado no chat
var
 sFile: string;
 t: QWord;
begin
  panArquivo.Visible := False;

  if not FTP.Connected or not FAuthenticated then begin
    ConectarFTP;
    Sleep(100);
  end;

  FWaitingSize := False;
  sFile := '';

  if (AArquivo = '') or not FAuthenticated then begin
    ShowMessageSimple(Self, 'Nome de arquivo inválido ou FTP não conectado!', icWarning);
    Exit;
  end;

  FTotalBytes  := 0;
  FTransferred := 0;
  FFile := nil;
  FWaitingSize := True;

  //obtém o tamanho do arquivo a ser baixado
  //FTP.SendMessage('SIZE ' + ChatRoom + '_' + AArquivo + FLE);
  FTP.List(ChatRoom + '_' + AArquivo); //retorna em DoReceive (também funciona)

  t := GetTickCount64; //milissegundos

  while FWaitingSize do begin
    Application.ProcessMessages;
    if ((GetTickCount64 - t) > 5000) then Break; // 5 segundos
  end;

  if (FTotalBytes <= 0) then begin
    ShowMessageSimple(Self, 'Não foi possível obter informações do arquivo!' +
                      sLineBreak + sLineBreak + AArquivo, icNegative);
    Exit;
  end;

  //local onde salvar o arquivo
  with SaveDialog1 do begin
    FileName := AArquivo.Replace(ChatRoom + '_', '');
    if Execute then
      sFile := FileName
    else
      Exit;
  end;

  FTotalArquivos :=  1;
  lblPanArq1.Caption := 'DOWNLOAD';
  lblPanArq2.Caption := 'DOWNLOAD';
  lblPanArquivoCount.Caption := '';
  lblPanArquivoNome.Caption  := AArquivo;
  lblPanArquivoSize.Caption  := GetFileSizeText( FTotalBytes );
  ProgressBar1.Position := 0;
  panArquivo.Left := (Self.Width - panArquivo.Width) div 2;

  if FAuthenticated then begin
    panArquivo.Visible := True;
    FCreateFilePath := sFile;

    //download via FTP - Monitore no evento OnReceive
    FTP.Retrieve( ChatRoom + '_' + AArquivo );
  end
end;

procedure TfrmChat.ConvidadoClickDelete(AIDUser: Integer; ANomeUser: string);
//remove o convidado do chat
var
  i: integer;
  U: TChatUserInfo;
begin
  Usuario_clicado := AIDUser;

  if ShowMessageQuery(self,'Remover Convidado','Remover o convidado do chat ?' +
                      sLineBreak + sLineBreak + ANomeUser,'Sim','Não','',icQuestion) = mrYes then
  begin
    for i := 0 to scrConvidados.ControlCount - 1 do
      if scrConvidados.Controls[i] is TChatUserInfo then begin
        U := TChatUserInfo(scrConvidados.Controls[i]);

        if U.Usuario_ID = AIDUser then begin
          scrConvidados.RemoveControl(scrConvidados.Controls[i]);
          Break;
        end;
      end; //if

      //lista de convidados em formato JSON
      FConvidados_List := GetToUsers;
  end; //if ShowMessageQuery
end;

procedure TfrmChat.ConvidadoClickInfo(AIDUser: Integer; ANomeUser: string);
begin
  Usuario_clicado := AIDUser;
  ShowMessage('Convidado Clicado:' + sLineBreak + ANomeUser);
end;

procedure TfrmChat.AdicionarCardMessageInicial(ADate: TDateTime);
//exibe a data inicial do chat
var
  CardMsg: TChatCardMessage;
begin
  CardMsg := TChatCardMessage.Create(scrChat);
  CardMsg.Parent := scrChat;
  CardMsg.InitialDate(ADate);

  ChatLayout.AddCardMessage(CardMsg);
end;

procedure TfrmChat.AdicionarConvidado(AIdOwner, AIdUser: Integer);
//adiciona um convidado à lista para o chat
var
  u: TChatUserInfo;
begin
  u := TChatUserInfo.Create(scrConvidados);
  u.Parent := scrConvidados;
  u.ImageList := imgIcons20;
  u.ImageListIndex := 0; //lixeira
  u.OnClickInfo := @ConvidadoClickInfo;
  u.OnClickDelete := @ConvidadoClickDelete;
  u.Setup(AIdOwner, AIdUser); //dono do chat e convidado

  ConvidadosLayout.AddConvidado(u);
end;

function TfrmChat.PodeEnviarMensagem(): Boolean;
//precisa ao menos um convidado para enviar Mensagem ou Arquivo
begin
  if scrConvidados.ComponentCount < 2 then begin
    ShowMessageSimple(Self,'Adicione um Convidado ao Chat!',icWarning);
    Exit(False);
  end;

  Result := True;
end;

function TfrmChat.GetFileTotalBytes(AData: string): Int64;
//tenta obter o tamanho do arquivo
//                           0             1 2        3           4     5   6  7     8
//FTP.List('gotify.png') => '-rw-r--r--    1 1003     1004        15750 Jan 18 17:16 gotify.png'
var
  f: array of string;
begin
  Result := 0;
  f := AData.Split([' '], TStringSplitOptions.ExcludeEmpty);

  try
    if High(f) > 7 then begin
      Result := StrToInt64Def(f[4], 0);
    end;
  finally
    SetLength(f, 0);
  end;
end;

procedure TfrmChat.ControleElementos(AEnabled: Boolean);
//ativa/destiva elementos conforme exibição do Panel de Upload/Download de arquivos
begin
  scrConvidados.Enabled := AEnabled;
  btnAdidcionaConvidados.Enabled := AEnabled;
  scrChat.Enabled := AEnabled;
  ListBoxEmojis.Enabled := AEnabled;
  edtMsg.Enabled := AEnabled;
  btnEnviarMsg.Enabled := AEnabled;
  btnEnviarArquivo.Enabled := AEnabled;
end;

procedure TfrmChat.LerConfig;
//ler configurações do servidor
var
  ArqINI: TIniFile;
  FArquivoINI: String;
begin
  FArquivoINI := ExtractFileDir( ParamStr(0) ) + PathDelim + 'chat_config.ini';
  ArqINI := TIniFile.Create(FArquivoINI);

  try
    FServer_Host   := ArqINI.ReadString('chat_ftp','host', '127.0.0.1');
    FServer_Port   := ArqINI.ReadInteger('chat_ftp','port', 21);
    FServer_User   := ArqINI.ReadString('chat_ftp','user', '');
    FServer_Pwd    := ArqINI.ReadString('chat_ftp','pwd', '');
    FServer_Folder := ArqINI.ReadString('chat_ftp','folder', '');
  finally
    ArqINI.Free;
  end;

  if FServer_Folder = PathDelim then FServer_Folder := '';
end;

procedure TfrmChat.ConectarFTP;
begin
  if FConnected and FAuthenticated then Exit;
  DesconectarFTP;
  FTP.Connect(FServer_Host, FServer_Port);
end;

procedure TfrmChat.DesconectarFTP;
begin
  FTP.Disconnect;
  FConnected := False;
  FAuthenticated := False;
end;

procedure TfrmChat.SendFile;
//envia o arquivo conforme o AIndex
var
  lBytes: Int64;
  sFile, sSize: string;
begin
  panArquivo.Visible := False;

  if (FFileCurrentIndex < 0) or (Low(FFilesToSend) < 0) or (High(FFilesToSend) < 0) then Exit;

  if (FCurrentFileName <> '') and (FFileCurrentIndex >= 0) then begin
    //renomeia o arquivo no servidor
    FTP.Rename( FCurrentFileName, ChatRoom + '_' + FCurrentFileName);

    //próximo arquivo
    FFileCurrentIndex := FFileCurrentIndex + 1;

    //envia a mensagem
    EnviarMensagem('chat', '', FCurrentFileName, GetFileSizeText(FFileCurrentSize));
  end;

  if (FFileCurrentIndex > High(FFilesToSend)) then begin
    FFileCurrentIndex := -1;
    FCurrentFileName := '';
    FFileCurrentSize := 0;
    Exit;
  end;

  lBytes := GetLocalFileSize( FFilesToSend[FFileCurrentIndex] );
  sSize  := GetFileSizeText( lBytes );
  sFile  := ExtractFileName( FFilesToSend[FFileCurrentIndex] );
  lblPanArquivoCount.Caption := Format('%d de %d',[FFileCurrentIndex+1, High(FFilesToSend)+1]);
  lblPanArquivoNome.Caption  := sFile;
  lblPanArquivoSize.Caption  := sSize;
  panArquivo.Visible := True;
  FCurrentFileName   := sFile;
  FFileCurrentSize   := lBytes;
  Application.ProcessMessages;

  //envia o arquivo - monitore no evento OnSent
  if FTP.Connected then
    FTP.Put( FFilesToSend[FFileCurrentIndex] );
end;

function TfrmChat.IsMinhaSala(): Boolean;
//sou o dono/criador da sala ?
begin
  Result := False;
  try
    Result := frmMain.GetUsuario_ID = StrToIntDef( ChatRoom.Split(['-'], TStringSplitOptions.ExcludeEmpty)[0], 0 );
  finally
  end;
end;

function TfrmChat.IdDonoSala(): integer;
//retorna o id do dono/criado da sala
begin
  Result := StrToIntDef( ChatRoom.Split(['-'], TStringSplitOptions.ExcludeEmpty)[0], frmMain.GetUsuario_ID );
end;

procedure TfrmChat.ResetAttention;
begin
  panTitulo.Color := FDefaultColor;
  FAttention := False;
  FAttentionSequence := 0; //até 10
  FAttentionCount := 0;
  FAttentionPeriod := 1;
end;

procedure TfrmChat.ResetWriting;
begin
  panWriting.Visible := False;
  FWritingSequence := 0; //até 10
  FWriting := False;
  FWritingCount := 0;
  FWritingPeriod := 1;
end;

procedure TfrmChat.ChatEventos(ASala: string; AJson: TJSONObject);
//recebe os eventos do servidor do chat
var
 evento: string;
begin
  if not Assigned(AJson) then Exit;
  evento := LowerCase( AJson.Get('event', '') );

  // Se estiver na conversa com FromID, adiciona o balão
  //AdicionarCardMessage(FromName, Msg, False);

  if (evento = 'chat') then begin

  end;
end;

procedure TfrmChat.ChatAvisos(AJson: TJSONObject);
//avisos diversos recebidos
var
 evento: string;
begin
  if not Assigned(AJson) then Exit;
  evento := LowerCase( AJson.Get('event', '') );

  if (evento = 'chat_retorno') then begin

  end else if (evento = 'logoff') then begin

  end else if (evento = 'attention') then begin
    //alguém chamando sua atenção
    if AJson.Get('from_id', 0) <> ChatClient.Meu_ID then begin
      ResetAttention;
      FAttention := True;
    end;
  end else if (evento = 'writing') then begin

  end else if (evento = 'connection') then begin

  end else if (evento = 'disconnection') then begin

  end else if (evento = 'user_online') then begin

  end else if (evento = 'user_offline') then begin

  end;
end;

procedure TfrmChat.EnviarArquivos(const AFileNames: array of string);
//envia arquivos ao servidor
var
  i, lQdeArquivos: integer;
  s: string;
  lTotalBytes, lBytes: Int64;
begin
  panArquivo.Visible := False;

  if not FTP.Connected or not FAuthenticated then begin
    ConectarFTP;
    Sleep(100);
  end;

  FTotalBytes := 0;
  FTransferred:= 0;
  FTotalArquivos := 0;
  FTotalArquivosTransferidos := 0;
  FFileCurrentSize := 0;
  FCurrentFileName := '';
  FDirListing := '';

  if not PodeEnviarMensagem() then Exit;

  lTotalBytes  := 0; //somatório de bytes de todos os arquivos
  lQdeArquivos := 4; //máximo de arquivos permitidos por vez

  if (Low(AFileNames) < 0) or (High(AFileNames)+1 > lQdeArquivos) then begin
   ShowMessageSimple(Self, Format('Permitido até %d arquivos!', [lQdeArquivos]), icWarning);
   Exit;
  end;

  //valida o tamanho dos arquivos individualemente
  s := '';

  for i := Low(AFileNames) to High(AFileNames) do begin
    lBytes := GetLocalFileSize( AFileNames[i] );
    lTotalBytes := lTotalBytes + lBytes;

    if (lBytes > FMaxFileSize) then begin
      if s <> '' then s := s + sLineBreak;
      s := s + ExtractFileName( AFileNames[i] ) +
           ' ( ' + GetFileSizeText( lBytes )  + ' )';
    end;
  end;

  if s <> '' then begin
    s := 'Arquivos excedem o tamanho máximo permitido de ' +
          GetFileSizeText( FMaxFileSize ) + sLineBreak + sLineBreak + s;
    ShowMessageSimple(Self, s, icWarning);
    Exit;
  end;

  //tudo ok
  if High(AFileNames)>0 then
    s := Format('Confirma o envio de %d arquivos ?', [High(AFileNames)+1])
  else
    s := 'Confirma o envio do arquivo ?';

  if ShowMessageQuery(self, 'Enviar Arquivos',s,'Sim','Não','',icQuestion) <> mrYes then Exit;

  //Vamos enviar os arquivos
  FTotalBytes    := lTotalBytes; //total de bytes dos arquivos
  FTotalArquivos := High(AFileNames) + 1;
  lblPanArq1.Caption := 'UPLOAD';
  lblPanArq2.Caption := 'UPLOAD';
  ProgressBar1.Position := 0;
  panArquivo.Left := (Self.Width - panArquivo.Width) div 2;

  if FAuthenticated then begin
    panArquivo.Visible := True;
    FFilesToSend := @AFileNames;
    FFileCurrentIndex := 0;
    SendFile;
  end
  else
    ShowMessageSimple(Self, 'Servidor FTP não está preparado!' + sLineBreak + sLineBreak + FFtpErroMsg, icNegative);
end;

function TfrmChat.GetFileSizeText(AValue: Int64): string;
//tamanho do arquivo em formato string: 10Kb, 2Mb, etc
var
  lkb, lmb, lgb: Int64;
begin
  lkb := 1024;
  lmb := 1024 * lkb;
  lgb := 1024 * lmb;

  if (AValue < lkb) then
    Result := FormatFloat('0 Bytes', AValue)
  else if (AValue < lmb) then
    Result := FormatFloat('0.0 KB', AValue / lkb)
  else if (AValue < lgb) then
    Result := FormatFloat('0.0 MB', AValue / lmb)
  else
    Result := FormatFloat('0.0 GB', AValue / lgb);
end;

function TfrmChat.GetLocalFileSize(const AFileName: string): Int64;
//obtém o total de bytes do arquivo local
var
  FS: TFileStream;
begin
  Result := 0;
  if not FileExists(AFileName) then Exit;
  FS := TFileStream.Create(AFileName, fmOpenRead or fmShareDenyNone);
  try
    Result := FS.Size;
  finally
    FS.Free;
  end;
end;

function TfrmChat.GetToUsers: TJSONArray;
//destinatários do chat
var
  i: Integer;
  u: TChatUserInfo;
begin
  ListaIDS := '';
  Result := TJSONArray.Create;

  if scrConvidados.ControlCount < 1 then Exit;

  for i := 0 to scrConvidados.ControlCount - 1 do begin
    if scrConvidados.Controls[i] is TChatUserInfo then begin
      u := TChatUserInfo( scrConvidados.Controls[i] );

      Result.Add( TJSONObject.Create([
                                      'to_id', u.Usuario_ID,
                                      'to_name', u.Usuario_Nome
                                     ])
                ); //add

      //adiciona à uma lista para não selecionar novamente
      if ListaIDS <> '' then ListaIDS := ListaIDS + ',';
      ListaIDS := ListaIDS + u.Usuario_ID.ToString;
    end; //if

  end; //for
end;

procedure TfrmChat.EnviarMensagem(AEvent, AMessage, AFileName, AFileSize: string);
//enviar a mensagem ao servidor do chat
var
  lMsg: TJSONObject;
  lTo: TJSONArray;
begin
  lMsg := TJSONObject.Create;
  lTo  := FConvidados_List;
  if Trim(AEvent) = '' then AEvent := 'chat';

  try
    lMsg.Add('event', AEvent);
    lMsg.Add('from_id', ChatClient.Meu_ID);
    lMsg.Add('from_name', ChatClient.Meu_Nome);
    lMsg.Add('room_name', ChatRoom);
    lMsg.Add('file_name', AFileName);
    lMsg.Add('file_size', AFileSize);
    lMsg.Add('msg', AMessage);
    lMsg.Add('to', lTo);

    ChatClient.SendMessage( lMsg.AsJSON );
  finally
    lMsg.Free;
  end;
end;

procedure TfrmChat.NotificaDigitacao;
//notifica aos membros da sala que estou digitando
var
  lMsg: TJSONObject;
begin
  lMsg := TJSONObject.Create;

  try
    lMsg.Add('event', 'writing');
    lMsg.Add('from_id', ChatClient.Meu_ID);
    lMsg.Add('from_name', ChatClient.Meu_Nome);

    ChatClient.SendMessage( lMsg.AsJSON );
  finally
    lMsg.Free;
  end;
end;

procedure TfrmChat.ChamarAtencao;
//chama a atenção dos membros da sala
var
  lMsg: TJSONObject;
begin
  lMsg := TJSONObject.Create;

  try
    lMsg.Add('event', 'attention');
    lMsg.Add('from_id', ChatClient.Meu_ID);
    lMsg.Add('from_name', ChatClient.Meu_Nome);

    ChatClient.SendMessage( lMsg.AsJSON );

    ShowMessageSimple(Self, 'Sua atenção foi comunicada à sala!', icPositive);
  finally
    lMsg.Free;
  end;
end;

end.

