unit View.Chat;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  Buttons, LCLType, LCLIntf, ComCtrls, fpjson,
  FPImage, FPReadPNG, FPReadJPEG, FPReadGIF,
  ChatBubble, ChatBubbleFile, ChatLayoutManager, ChatUserInfo, Util.FTPClient;

type
  TTransferFiles = (tfUpload, tfDownload, tfNone);

  { TfrmChat }

  TfrmChat = class(TForm)
    btnEnviarArquivo: TSpeedButton;
    imgChatIcones: TImageList;
    lblPanArquivoNome: TLabel;
    lblPanArq1: TLabel;
    lblPanArq2: TLabel;
    lblPanArquivoSize: TLabel;
    lblPanArquivoCount: TLabel;
    lblTituloConvidados: TLabel;
    lblTituloChat: TLabel;
    lblTituloEmoji: TLabel;
    OpenDialog1: TOpenDialog;
    panArquivo: TPanel;
    panTitulo: TPanel;
    lblPanTitulo1: TLabel;
    lblPanTitulo2: TLabel;
    ProgressBar1: TProgressBar;
    SaveDialog1: TSaveDialog;
    scrChat: TScrollBox;
    scrConvidados: TScrollBox;
    ListBoxEmojis: TListBox;
    btnEnviarMsg: TSpeedButton;
    imgIcons20: TImageList;
    edtMsg: TMemo;
    btnAdidcionaConvidados: TSpeedButton;

    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure FormCreate(Sender: TObject);
    procedure FormDropFiles(Sender: TObject; const AFileNames: array of string);
    procedure scrChatResize(Sender: TObject);
    procedure scrConvidadosResize(Sender: TObject);
    procedure btnAdidcionaConvidadosClick(Sender: TObject);
    procedure btnEnviarArquivoClick(Sender: TObject);
    procedure btnEnviarMsgClick(Sender: TObject);
    procedure ListBoxEmojisClick(Sender: TObject);
  private
    FFTP: TFTPClient;
    ChatLayout: TChatLayoutManager;
    ConvidadosLayout: TChatLayoutManager;
    Usuario_clicado: integer;
    FTotalBytes, FTransferred: Int64;
    FTotalArquivos, FTotalArquivosTransferidos: Integer;
    ListaIDS: string;
    procedure AdicionarBalaoInicial(ADate: TDateTime);
    procedure ConvidadoAlteraStatus(AIdUser: Integer; AStatus: Boolean);
    procedure ConvidadoMsgNaoLidas(AIdUser, AQdeNaoLida: Integer);
    procedure EnviarArquivos(const AFileNames: array of string);
    procedure MsgRecebida(FromID: Integer; FromName: string; Msg: string);
    procedure ListaRecebida(Users: TJSONArray);
    procedure AdicionarBalao(ARemetente,ATexto: string; AEnviadaPorMim: Boolean);
    procedure AdicionarBalaoArquivo(AFileName: string; ASize: Int64; AEnviadaPorMim: Boolean);
    procedure BobbleClick(AChatID: Integer; AArquivo: string; ASize: Int64);
    procedure ConvidadoClickDelete(AIDUser: Integer; ANomeUser: string);
    procedure ConvidadoClickInfo(AIDUser: Integer; ANomeUser: string);
    procedure IniciaListaConvidados;
    function PodeEnviarMensagem(): Boolean;
    procedure ControleElementos(AEnabled: Boolean);
  public
    ChatRoom: string;
    procedure OnTransferProgress(const ACurrent, AMax, APercent: Integer) ;
    procedure OnTransferLog(const AMsg: string);
    procedure OnTransferDone(const AFileName: string; ATotalBytes: Int64);
    procedure OnTransferError(const AError: string);
  end;

var
  frmChat: TfrmChat;

implementation

uses
  ChatModule,
  View.Main, View.MessageQuery, View.ChatUsuarios,
  Util.MessagePopup;

{$R *.lfm}

{ TfrmChat }

procedure TfrmChat.FormCreate(Sender: TObject);
begin
  Self.AllowDropFiles := True;
  ChatRoom := DMChatCliente.NewRoom( frmMain.GetUsuario_ID );
  ChatLayout := TChatLayoutManager.Create( scrChat );
  ConvidadosLayout := TChatLayoutManager.Create( scrConvidados );
  ListaIDS := frmMain.GetUsuario_ID.ToString;
  FTotalBytes    := 0;
  FTransferred   := 0;
  FTotalArquivos := 0;
  FTotalArquivosTransferidos := 0;

  //ftp
  FFTP := TFTPClient.Create;
  FFTP.OnProgress := @OnTransferProgress;
  FFTP.OnLog      := @OnTransferLog;
  FFTP.OnDone     := @OnTransferDone;
  FFTP.OnError    := @OnTransferError;

  //chat controler
  DMChatCliente.OnChat := @MsgRecebida;
  DMChatCliente.OnListUsers := @ListaRecebida;

  // Emojis compatíveis
  ListBoxEmojis.Items.AddStrings([
    '😀','😃','😄','😁','😆','😅',
    '😂','🙂','😉','😊','😍','😘',
    '😜','😎','😢','😭','😡','😱',
    '😴','😇','🤩','😫','❤️','💔',
    '👍','👎','👌','🙌','👏','⭐',
    '🔥','💡','✔' ,'❌','⚠' ,'⚡',
    '⏰','🍀','📩','📤','📎','📞'
  ]);
end;

procedure TfrmChat.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
  FreeAndNil(ChatLayout);
  FreeAndNil(ConvidadosLayout);
  if Assigned(FFTP) then FreeAndNil(FFTP);
end;

procedure TfrmChat.FormDropFiles(Sender: TObject; const AFileNames: array of string);
//arrastando e soltando os arquivos
var
  P: TPoint;
begin

  //posição do mouse no momento em que os arquivos foram soltos
  P := ScreenToClient(Mouse.CursorPos);

  //Verifica se o controle é a ScrollBox do chat
  if (PtInRect(scrChat.BoundsRect, P)) then
    EnviarArquivos(AFileNames);
end;

procedure TfrmChat.ListBoxEmojisClick(Sender: TObject);
begin
  edtMsg.Text := edtMsg.Text + ListBoxEmojis.GetSelectedText;
end;

procedure TfrmChat.scrChatResize(Sender: TObject);
// ajusta os elementos dentro do scrollview para ajustá-los
// quando a barra de rolagem surgir
begin
  ChatLayout.RecalculateLayout;
end;

procedure TfrmChat.scrConvidadosResize(Sender: TObject);
// ajusta os elementos dentro do scrollview para ajustá-los
// quando a barra de rolagem surgir
begin
  ConvidadosLayout.RecalculateLayout;
end;

procedure TfrmChat.IniciaListaConvidados;
//o criador do chat deve ser o primeiro da lista
var
  U: TChatUserInfo;
begin
  ConvidadosLayout.Clear;
  U := TChatUserInfo.Create(scrConvidados);
  U.Parent := scrConvidados;
  U.ImageList := imgIcons20;
  U.ImageListIndex := 0; //lixeira
  U.OnClickInfo := @ConvidadoClickInfo;
  U.OnClickDelete := @ConvidadoClickDelete;
  U.Setup(frmMain.GetUsuario_ID, frmMain.GetUsuario_ID);

  ConvidadosLayout.AddConvidado(U);
end;

procedure TfrmChat.btnEnviarMsgClick(Sender: TObject);
begin
  if Trim(edtMsg.Text) = '' then Exit;
  if not PodeEnviarMensagem() then Exit;

  edtMsg.Clear;
  edtMsg.SetFocus;
end;

procedure TfrmChat.btnAdidcionaConvidadosClick(Sender: TObject);
var
  f: TfrmChatUsuarios;
  U: TChatUserInfo;
  i, iduser: Integer;
begin
  //ListaIDS := frmMain.GetUsuario_ID.ToString;

  f := TfrmChatUsuarios.Create(Self);
  f.ListaExcluidos := ListaIDS;
  f.ShowModal;

  if f.Selecionou then begin
    for i := 0 to f.ListaConvidados.Count -1 do begin
      iduser := StrToInt( f.ListaConvidados[i] );

      if iduser <> frmMain.GetUsuario_ID then begin
        U := TChatUserInfo.Create(scrConvidados);
        U.Parent := scrConvidados;
        U.ImageList := imgIcons20;
        U.ImageListIndex := 0; //lixeira
        U.OnClickInfo := @ConvidadoClickInfo;
        U.OnClickDelete := @ConvidadoClickDelete;
        U.Setup(frmMain.GetUsuario_ID, iduser);

        ConvidadosLayout.AddConvidado(U);

        if ListaIDS <> '' then ListaIDS := ListaIDS + ',';
        ListaIDS := ListaIDS + iduser.ToString;
      end; //if
    end; //for
  end;

  f.Free;
end;

procedure TfrmChat.btnEnviarArquivoClick(Sender: TObject);
var
  lArquivos: array of String;
  i: integer;
  b: Boolean;
begin
  b := False;
  with OpenDialog1 do begin
    if Execute then
      if (Files.Count > 0) then begin
        SetLength(lArquivos, Files.Count);
        b := True;
        for i := 0 to Files.Count - 1 do
          lArquivos[i] := Files[i];
      end;
  end;

  if b then
    EnviarArquivos(lArquivos);

  SetLength(lArquivos, 0);
end;

procedure TfrmChat.ConvidadoAlteraStatus(AIdUser: Integer; AStatus: Boolean);
//altera o status (on/off line) do convidado
var
  i: Integer;
  U: TChatUserInfo;
  Status: TChatUserStatus;
begin
  if AIdUser < 1 then Exit;

  for i := 0 to scrConvidados.ComponentCount - 1 do begin
    U := TChatUserInfo(scrConvidados.Components[i]);
    if U.Usuario_ID = AIdUser then begin
      if AStatus then
        U.Status := usOnline
      else
        U.Status := usOffline;
      //scrConvidados.Invalidate;
      Break;
    end;
  end;
end;

procedure TfrmChat.ConvidadoMsgNaoLidas(AIdUser, AQdeNaoLida: Integer);
//altera msg não lida do convidado
var
  i: Integer;
  U: TChatUserInfo;
begin
  if AIdUser < 1 then Exit;

  for i := 0 to scrConvidados.ComponentCount - 1 do begin
    U := TChatUserInfo(scrConvidados.Components[i]);
    if U.Usuario_ID = AIdUser then begin
      U.UnreadCount := AQdeNaoLida;
      //scrConvidados.Invalidate;
      Break;
    end;
  end;
end;

procedure TfrmChat.MsgRecebida(FromID: Integer; FromName: string; Msg: string);
begin
  // Se estiver na conversa com FromID, adiciona o balão
  AdicionarBalao(FromName, Msg, False);
end;

procedure TfrmChat.ListaRecebida(Users: TJSONArray);
var
  U: TChatUserInfo;
  i, idProprietarioChat: Integer;
begin
  idProprietarioChat := 1;

  for i := scrConvidados.ControlCount - 1 downto 0 do
    scrConvidados.Controls[i].Free;

  //U := TChatUserInfo.Create(scrConvidados);
  //U.Parent := scrConvidados;
  //U.ImageList := imgIcons20;
  //U.ImageListIndex := 0; //lixeira
  //U.OnClickInfo := @ConvidadoClickInfo;
  //U.OnClickDelete := @ConvidadoClickDelete;
  //U.Setup(idProprietarioChat, iduser, nome, imgAvatar);
  //
  //// Auto-scroll
  //scrConvidados.VertScrollBar.Position := scrConvidados.VertScrollBar.Range;
end;

procedure TfrmChat.AdicionarBalao(ARemetente, ATexto: string;
  AEnviadaPorMim: Boolean);
var
  Balao: TChatBubble;
  TimeStr: string;
begin
  if scrChat.ControlCount = 0 then
    AdicionarBalaoInicial(Now);

  TimeStr := FormatDateTime('hh:nn', Now);

  Balao := TChatBubble.Create(scrChat);
  Balao.Parent := scrChat;
  Balao.Setup(1, ARemetente, ATexto, TimeStr, AEnviadaPorMim, TBubbleMessageStatus.msRead);

  ChatLayout.AddBubble(Balao);
end;

procedure TfrmChat.AdicionarBalaoArquivo(AFileName: string; ASize: Int64; AEnviadaPorMim: Boolean);
var
  Balao: TChatBubbleFile;
  TimeStr: string;
begin
  if scrChat.ControlCount = 0 then
    AdicionarBalaoInicial(Now);

  TimeStr := FormatDateTime('hh:nn', Now);

  Balao := TChatBubbleFile.Create(scrChat);
  Balao.Parent := scrChat;
  Balao.ImageList := imgChatIcones;
  Balao.OnClickEvent := @BobbleClick;
  Balao.Setup(1, AFileName, ASize, TimeStr, AEnviadaPorMim, TBubbleFileMessageStatus.msRead);

  ChatLayout.AddBubbleFile(Balao);
end;

procedure TfrmChat.BobbleClick(AChatID: Integer; AArquivo: string; ASize: Int64);
begin
  if AArquivo = '' then Exit;
  with SaveDialog1 do begin
    FileName := AArquivo;
    Execute;
  end;
end;

procedure TfrmChat.ConvidadoClickDelete(AIDUser: Integer; ANomeUser: string);
var
  i: integer;
  U: TChatUserInfo;
begin
  Usuario_clicado := AIDUser;

  if ShowMessageQuery(self,'Remover Convidado','Remover o convidado da sala ?' + sLineBreak + sLineBreak + ANomeUser,'Sim','Não','',icQuestion) = mrYes then begin
    for i := 0 to scrConvidados.ControlCount - 1 do
      if scrConvidados.Controls[i] is TChatUserInfo then begin
        U := TChatUserInfo(scrConvidados.Controls[i]);

        if U.Usuario_ID = AIDUser then begin
          scrConvidados.RemoveControl(scrConvidados.Controls[i]);
          Break;
        end;
      end; //if
  end; //if ShowMessageQuery
end;

procedure TfrmChat.ConvidadoClickInfo(AIDUser: Integer; ANomeUser: string);
begin
  Usuario_clicado := AIDUser;
  ShowMessage('Convidado Cliccado:' + sLineBreak + ANomeUser);
end;

procedure TfrmChat.AdicionarBalaoInicial(ADate: TDateTime);
//exibe a data inicial do chat
var
  Balao: TChatBubble;
begin
  Balao := TChatBubble.Create(scrChat);
  Balao.Parent := scrChat;
  Balao.InitialDate(ADate);

  ChatLayout.AddBubble(Balao);
end;

function TfrmChat.PodeEnviarMensagem(): Boolean;
//precisa ao menos um convidado para enviar Mensagem ou Arquivo
begin
  if scrConvidados.ComponentCount < 2 then begin
    ShowMessageSimple(Self,'Adicione um Convidado ao Chat!',icWarning);
    Exit(False);
  end;

  Result := True;
end;

procedure TfrmChat.ControleElementos(AEnabled: Boolean);
//ativa/destiva elementos conforme exibição do Panel de Upload/Download de arquivos
begin
  scrConvidados.Enabled := AEnabled;
  btnAdidcionaConvidados.Enabled := AEnabled;
  scrChat.Enabled := AEnabled;
  ListBoxEmojis.Enabled := AEnabled;
  edtMsg.Enabled := AEnabled;
  btnEnviarMsg.Enabled := AEnabled;
  btnEnviarArquivo.Enabled := AEnabled;
end;

procedure TfrmChat.OnTransferProgress(const ACurrent, AMax, APercent: Integer);
//atualiza a barra de progresso
begin
  FTransferred := FTransferred + ACurrent;
  ProgressBar1.Position := Round(FTransferred / FTotalBytes * 100);
end;

procedure TfrmChat.OnTransferLog(const AMsg: string);
//log da transferência do arquivos
begin
  edtMsg.Append('LOG: ' + AMsg);
end;

procedure TfrmChat.OnTransferDone(const AFileName: string; ATotalBytes: Int64);
//transferência dos arquivos concluída
begin
  AdicionarBalaoArquivo(AFileName, ATotalBytes, True);

  if FTotalArquivosTransferidos = FTotalArquivos then begin
    ProgressBar1.Position := 100;
    ShowMessageSimple(Self, 'Upload concluído!', icPositive);
    panArquivo.Visible := False;
    if Assigned(FFTP) then FreeAndNil(FFTP);
  end;
end;

procedure TfrmChat.OnTransferError(const AError: string);
//erro na transferência do arquivo
begin
  edtMsg.Append('ERRO: ' + AError);
  if Assigned(FFTP) and not FFTP.IsAllDone() then begin
    ShowMessageSimple(Self, AError, icNegative);
    panArquivo.Visible := False;
    FFTP.Free;
  end;
end;

procedure TfrmChat.EnviarArquivos(const AFileNames: array of string);
//envia arquivos ao servidor
var
  i, lQdeArquivos: integer;
  s, sErro, sSize: string;
  lMaxFileSize, lTotalBytes, lBytes: Int64;
  lTime: QWord;
begin
  FTotalBytes := 0;
  FTransferred:= 0;
  FTotalArquivos := 0;
  FTotalArquivosTransferidos := 0;

  if not PodeEnviarMensagem() then Exit;

  lMaxFileSize := TFTPClient.New.MaxFileSize; //4Mb
  lTotalBytes  := 0;
  lQdeArquivos := 4;

  if (Low(AFileNames) < 0) or (High(AFileNames)+1 > lQdeArquivos) then begin
   ShowMessageSimple(Self, Format('Permitido até %d arquivos!', [lQdeArquivos]), icWarning);
   Exit;
  end;

  //valida o tamanho dos arquivos individualemente
  s := '';

  for i := Low(AFileNames) to High(AFileNames) do begin
    lBytes := TFTPClient.New.GetLocalFileSize( AFileNames[i] );
    lTotalBytes := lTotalBytes + lBytes;

    if (lBytes > lMaxFileSize) then begin
      if s <> '' then s := s + sLineBreak;
      s := s + ExtractFileName( AFileNames[i] ) +
           ' ( ' + TFTPClient.New.GetFileSizeText( lBytes )  + ' )';
    end;
  end;

  if s <> '' then begin
    s := 'Arquivos excedem o tamanho máximo permitido de ' +
          TFTPClient.New.GetFileSizeText( lMaxFileSize ) + sLineBreak + sLineBreak + s;
    ShowMessageSimple(Self, s, icWarning);
    Exit;
  end;

  //tudo ok
  FTotalBytes    := lTotalBytes; //total de bytes dos arquivos
  FTotalArquivos := High(AFileNames)+1;

  if High(AFileNames)>0 then
    s := Format('Confirma o envio de %d arquivos ?', [High(AFileNames)+1])
  else
    s := 'Confirma o envio do arquivo ?';

  if ShowMessageQuery(self, 'Enviar Arquivos',s,'Sim','Não','',icQuestion) <> mrYes then Exit;

  //Vamos enviar os arquivos
  s := '';
  sErro := '';
  lblPanArq1.Caption := 'UPLOAD';
  lblPanArq2.Caption := 'UPLOAD';
  ProgressBar1.Position := 0;
  panArquivo.Visible := True;

  FFTP.Start;
  FFTP.Connect; //utiliza dados do arquivo chat_config.ini

  //lTime := GetTickCount64;
  //
  //while lTime - GetTickCount64 < 5 do
  //  Application.ProcessMessages;

  if FFTP.IsAllDone() then begin
    for i := Low(AFileNames) to High(AFileNames) do begin
      lBytes := FFTP.GetLocalFileSize( AFileNames[i] );
      sSize  := FFTP.GetFileSizeText( lBytes );
      s := ExtractFileName( AFileNames[i] );
      lblPanArquivoCount.Caption := Format('%d de %d',[i, High(AFileNames)+1]);
      lblPanArquivoNome.Caption  := s;
      lblPanArquivoSize.Caption  := sSize;

      //envia o arquivo
      if FFTP.IsAllDone() then begin
        FTotalArquivosTransferidos := FTotalArquivosTransferidos + 1;
        FFTP.Upload(AFileNames[i], ChatRoom + '_' + s);
      end else begin
        sErro := 'Falha na transmissão!' + sLineBreak + sLineBreak + FFTP.GetMessage;
        Break;
      end;

      while not FFTP.IsTransferConcluded do begin
        //aguarda terminar a transferência do arquivo
        Application.ProcessMessages;
      end;

    end; //for
  end else begin
    sErro := 'Servidor FTP não está preparado!' + sLineBreak + sLineBreak + FFTP.GetMessage;
  end;

  if sErro <> '' then begin
    ShowMessageSimple(Self, sErro, icNegative);
  end;
end;

end.

